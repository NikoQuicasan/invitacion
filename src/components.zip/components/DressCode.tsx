import clsx from 'clsx';
import flor1 from '../assets/hotel/flor1.png';

// Ícono floral centrado para las columnas — mismo estilo de trazo que
// FloralCorner pero pensado para ir centrado sobre un título, no en una esquina.
function FloralIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <g stroke="currentColor" strokeWidth="1.3" strokeLinecap="round">
        <path d="M50 115 L50 55" />
        <path d="M50 90 C 35 85, 30 70, 38 58" />
        <path d="M50 75 C 65 70, 70 55, 62 42" />
        <ellipse cx="50" cy="35" rx="10" ry="16" fill="currentColor" opacity="0.15" />
        <ellipse cx="35" cy="45" rx="9" ry="14" transform="rotate(-35 35 45)" fill="currentColor" opacity="0.15" />
        <ellipse cx="65" cy="45" rx="9" ry="14" transform="rotate(35 65 45)" fill="currentColor" opacity="0.15" />
        <circle cx="50" cy="32" r="4" fill="currentColor" opacity="0.5" />
      </g>
    </svg>
  );
}

export default function DressCode() {
  return (
    <section className={clsx('relative', 'w-full', 'min-h-[100dvh]', 'flex', 'flex-col', 'items-center', 'justify-center', 'py-20', 'px-6', 'bg-[#563b31]', 'text-[#F6F1E9]', 'overflow-hidden')}>

      {/* Flores decorativas: esquina superior derecha e inferior izquierda */}
      <img
        src={flor1}
        alt=""
        aria-hidden="true"
        className={clsx('absolute', 'top-0', 'right-0', 'w-40', 'sm:w-48', 'md:w-60', 'h-auto', 'opacity-80', 'pointer-events-none', 'select-none', 'z-0', 'rotate-180')}
      />
      <img
        src={flor1}
        alt=""
        aria-hidden="true"
        className={clsx('absolute', 'bottom-0', 'left-0', 'w-40', 'sm:w-48', 'md:w-60', 'h-auto', 'opacity-80', 'pointer-events-none', 'select-none', 'z-0')}
      />

      {/* Título, estilo "THE CEREMONY" de la referencia */}
      <div className={clsx('relative', 'z-10', 'text-center', 'mb-16', 'md:mb-20')}>
        <h2 className={clsx('font-cormorant', 'text-4xl', 'md:text-5xl', 'tracking-[0.2em]', 'uppercase')}>
          Código De Vestimenta
        </h2>
        <p className={clsx('font-montserrat', 'text-[10px]', 'md:text-xs', 'tracking-widest', 'opacity-70', 'uppercase', 'mt-3')}>
          Formal / Elegante
        </p>
      </div>

      {/* Columnas: Hombres / Mujeres */}
      <div className={clsx('relative', 'z-10', 'w-full', 'max-w-2xl', 'grid', 'grid-cols-2', 'gap-8', 'md:gap-16')}>

        <div className={clsx('flex', 'flex-col', 'items-center', 'text-center')}>
          <FloralIcon className={clsx('w-14', 'h-16', 'md:w-16', 'md:h-20', 'mb-5', 'text-[#F6F1E9]/80')} />
          <h3 className={clsx('font-cormorant', 'text-xl', 'md:text-2xl', 'tracking-wide', 'uppercase', 'mb-3')}>
            Hombres
          </h3>
          <p className={clsx('font-montserrat', 'text-[11px]', 'md:text-xs', 'leading-relaxed', 'opacity-80', 'max-w-[220px]')}>
            Traje formal en tonos tierra o neutros, camisa de vestir y, si gustan, corbata o corbatín.
          </p>
        </div>

        <div className={clsx('flex', 'flex-col', 'items-center', 'text-center')}>
          <FloralIcon className={clsx('w-14', 'h-16', 'md:w-16', 'md:h-20', 'mb-5', 'text-[#F6F1E9]/80')} />
          <h3 className={clsx('font-cormorant', 'text-xl', 'md:text-2xl', 'tracking-wide', 'uppercase', 'mb-3')}>
            Mujeres
          </h3>
          <p className={clsx('font-montserrat', 'text-[11px]', 'md:text-xs', 'leading-relaxed', 'opacity-80', 'max-w-[220px]')}>
            Vestido largo o midi en tonos tierra, evitando el blanco y los tonos muy claros.
          </p>
        </div>

      </div>

    </section>
  );
}